bl_info = {
    "name": "Braille Generator",
    "blender": (2, 80, 0),
    "category": "Object",
}

import bpy
import bmesh
import pybrl as brl

# Operator to set the scene units to millimeters and adjust the overlay scale
class SetUnitsToMM(bpy.types.Operator):
    bl_idname = "scene.set_units_to_mm"
    bl_label = "Set Scene Units to MM"

    def execute(self, context):
        bpy.context.scene.unit_settings.scale_length = 0.001
        bpy.context.scene.unit_settings.length_unit = 'MILLIMETERS'
        bpy.context.space_data.overlay.grid_scale = 0.001
        return {'FINISHED'}

class BrailleGenerator(bpy.types.Operator):
    
    """Braille Generator"""
    bl_idname = "object.braille_dots"
    bl_label = "Braille Generator"
    bl_options = {'REGISTER', 'UNDO'}
    
    # Properties for the Braille Generator
    phrase: bpy.props.StringProperty(name='Braille Text', 
                                    description='Text to be converted into Braille', 
                                    translation_context='*', 
                                    default='')
                                    
    subdivisions: bpy.props.IntProperty(name="Dot Subdivisions", 
                                        description="Number of subdivisions used for each dot",
                                        default=3, 
                                        min=2, 
                                        max=5)
                                        
    max_row_length: bpy.props.IntProperty(name="Max Row Length", 
                                          description="Maximum Braille characters in a given row",
                                          default=100, 
                                          min=1, 
                                          max=200)
                                          
    dot_radius: bpy.props.FloatProperty(name="Dot Radius", 
                                      description="Radius (in mm) of each individual Braille dot",
                                      default=0.775, 
                                      min=0.75, 
                                      max=0.8)
                                      
    dot_height: bpy.props.FloatProperty(name="Dot Height", 
                                  description="Height (in mm) of each individual Braille dot",
                                  default=0.75, 
                                  min=0.6, 
                                  max=0.9)
                                          
    dot_spacing: bpy.props.FloatProperty(name="Dot Spacing", 
                                      description="Space (in mm) between each Braille dot in a character",
                                      default=2.45, 
                                      min=2.3, 
                                      max=2.5)
                                      
    character_spacing: bpy.props.FloatProperty(name="Character Spacing", 
                                  description="Space (in mm) between each character",
                                  default=6.8, 
                                  min=6.1, 
                                  max=7.6)
                                      
    row_spacing: bpy.props.FloatProperty(name="Row Spacing", 
                              description="Space (in mm) between each row of text",
                              default=10.1, 
                              min=10, 
                              max=10.2)

    def execute(self, context):

        # Relative locations of each Braille dot
        locs = {0 : [0, 2, 0], 
                1 : [0, 1, 0], 
                2 : [0, 0, 0], 
                3 : [1, 2, 0], 
                4 : [1, 1, 0], 
                5 : [1, 0, 0]}

        
        # Extracts user-given data into handy variables
        phrase = self.phrase
        subdivisions = self.subdivisions
        max_row_length = self.max_row_length
        phrase = brl.translate(self.phrase.lower())

        # Initializes spacing variables
        row_offset = 0
        row_length = 0
        letter_offset = 0

        # List for holding generated dots
        generated_objects = []

        # Iterates over each word in user-given phrase
        for word in phrase:
            
            # Handles when a word is longer than the maximum row length allows
            row_length += len(word)
            if row_length > max_row_length:
                row_length = 0
                letter_offset = 0
                row_offset += self.row_spacing
            else:
                row_length += 1
            
            # Iterates over each character
            for letter in word:
                
                # Iterates over each dot
                for idx, dot in enumerate(letter):
                    
                    # Only runs if dot present
                    if dot=="1":
                    
                        # Initializes dot location data
                        loc_use = locs[idx].copy()
                        loc_use[0] = loc_use[0]*self.dot_spacing + letter_offset
                        loc_use[1] = loc_use[1]*self.dot_spacing - row_offset

                        # Generates an icosphere with user-given sizing
                        bpy.ops.mesh.primitive_ico_sphere_add(
                            subdivisions=subdivisions,
                            radius=self.dot_radius,
                            location=loc_use,
                            scale=(1, 1, self.dot_height/self.dot_radius)
                        )

                        # Converts icosphere into hemisphere
                        icosphere = bpy.context.object
                        bpy.ops.object.mode_set(mode='EDIT')
                        bm = bmesh.from_edit_mesh(icosphere.data)
                        bottom_verts = [v for v in bm.verts if v.co.z < -0.01]
                        if bottom_verts:
                            bmesh.ops.scale(bm, verts=bottom_verts, vec=(0.01, 0.01, 0.01))
                            bmesh.ops.remove_doubles(bm, verts=bottom_verts, dist=0.02)
                        bmesh.update_edit_mesh(icosphere.data)
                        bpy.ops.object.mode_set(mode='OBJECT')
                        bpy.ops.object.mode_set(mode='EDIT')
                        bpy.ops.mesh.normals_make_consistent(inside=False)
                        bpy.ops.object.mode_set(mode='OBJECT')

                        # Renames object and adds it to list
                        icosphere.name = "Dot"
                        generated_objects.append(icosphere)
                    
                letter_offset += self.character_spacing
            letter_offset += self.character_spacing

        # Join all generated objects into a single mesh
        if generated_objects:
            bpy.ops.object.select_all(action='DESELECT')
            for obj in generated_objects:
                obj.select_set(True)
            bpy.context.view_layer.objects.active = generated_objects[0]
            bpy.ops.object.join()

            # Set the origin to the geometry center with Z-coordinate at 0
            bpy.ops.object.origin_set(type='ORIGIN_CENTER_OF_VOLUME', center='BOUNDS')
            bpy.context.object.location.xy = (0, 0)
            bpy.ops.object.origin_set(type='ORIGIN_CURSOR', center='BOUNDS')

        return {"FINISHED"}

# Panel for the dropdown menu
class BrailleGeneratorPanel(bpy.types.Panel):
    bl_label = "Braille Generator"
    bl_idname = "VIEW3D_PT_braille_generator"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Braille'

    def draw(self, context):
        layout = self.layout
        layout.operator(BrailleGenerator.bl_idname)
        layout.operator(SetUnitsToMM.bl_idname)

def menu_func(self, context):
    self.layout.operator(BrailleGenerator.bl_idname)

addon_keymaps = []

def register():
    bpy.utils.register_class(BrailleGenerator)
    bpy.utils.register_class(SetUnitsToMM)
    bpy.utils.register_class(BrailleGeneratorPanel)
    bpy.types.VIEW3D_MT_object.append(menu_func)

    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    if kc:
        km = wm.keyconfigs.addon.keymaps.new(name='Object Mode', space_type='EMPTY')
        kmi = km.keymap_items.new(BrailleGenerator.bl_idname, 'B', 'PRESS', ctrl=True, shift=True)
        addon_keymaps.append((km, kmi))

def unregister():
    for km, kmi in addon_keymaps:
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()

    bpy.utils.unregister_class(BrailleGenerator)
    bpy.utils.unregister_class(SetUnitsToMM)
    bpy.utils.unregister_class(BrailleGeneratorPanel)
    bpy.types.VIEW3D_MT_object.remove(menu_func)

if __name__ == "__main__":
    register()
