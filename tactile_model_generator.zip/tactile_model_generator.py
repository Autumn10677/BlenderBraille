bl_info = {
    "name": "Tactile Model Block Generator",
    "blender": (4, 0, 0),
    "category": "Object",
}

import bpy
import bmesh
from bpy.props import StringProperty, IntProperty, FloatProperty
from bpy.types import Operator, Panel, PropertyGroup
from bpy_extras.io_utils import ImportHelper

# Properties for the custom operator
class CubeGeneratorProperties(PropertyGroup):
    subdivision: IntProperty(
        name="Subdivision Cuts",
        description="Number of subdivision cuts for the top face",
        default=20,
        min=1,
        max=100
    )

    image_path: StringProperty(
        name="Image Path",
        description="Path to the PNG file",
        default="",
        subtype='FILE_PATH'
    )


# Operator to open file dialog and set the image path
class SetImagePathOperator(bpy.types.Operator, ImportHelper):
    bl_idname = "object.set_image_path"
    bl_label = "Set Image Path"

    # Allow various image formats
    filter_glob: StringProperty(
        default="*.png;*.jpg;*.jpeg;*.bmp;*.tga;*.tiff;*.exr",
        options={'HIDDEN'},
        maxlen=255,
    )

    def execute(self, context):
        context.scene.png_cube_generator_props.image_path = self.filepath
        return {'FINISHED'}


# Operator to create the cube with the specified properties
class CreateCubeOperator(bpy.types.Operator):
    bl_idname = "object.create_cube"
    bl_label = "Create Cube"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        props = context.scene.png_cube_generator_props
        if not props.image_path:
            self.report({'ERROR'}, "No image file selected")
            return {'CANCELLED'}

        try:
            
            # Load the image into Blender
            image = bpy.data.images.load(props.image_path)

            # Extract the image dimensions
            width, height = image.size
            maxdim = max([width, height])
            width = 2*width/maxdim
            height = 2*height/maxdim

            # Create the cube
            bpy.ops.mesh.primitive_cube_add(size=1)
            cube = context.active_object

            # Scale the cube to match the image dimensions and depth
            cube.scale = (width, height, 1)
            
            bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

            obj = bpy.context.object
            obj.data.uv_layers.new(name="UVMap")

            # Access the mesh data with bmesh
            bpy.ops.object.mode_set(mode='EDIT')
            me = cube.data
            bm = bmesh.from_edit_mesh(me)
            bmesh.update_edit_mesh(me)

            # Find and select the top face
            max_z = float('-inf')
            top_face = None

            for face in bm.faces:
                avg_z = sum(v.co.z for v in face.verts) / len(face.verts)
                if avg_z > max_z:
                    max_z = avg_z
                    top_face = face

            if top_face:
                # Deselect all faces
                bpy.ops.mesh.select_all(action='DESELECT')

                # Select the top face
                top_face.select = True

                # Subdivide the selected top face with user-defined cuts
                bpy.ops.mesh.subdivide(number_cuts=props.subdivision)
                bpy.ops.mesh.subdivide(number_cuts=2)

                # Update the mesh
                bmesh.update_edit_mesh(me)

                # Create and assign vertex group
                bpy.ops.object.mode_set(mode='OBJECT')
                vertex_group = obj.vertex_groups.new(name="TopFaceGroup")
                
                # Add vertices to the vertex group
                bm = bmesh.new()
                bm.from_mesh(me)
                idx_list = [v.index for v in bm.verts if (v.co.z > max_z - 0.01)]  # Consider some tolerance
                
                for idx in idx_list:
                    vertex_group.add([idx], 1.0, 'ADD')
                
                bm.free()

            # Switch back to Object Mode
            bpy.ops.object.mode_set(mode='OBJECT')

            # Add Displace Modifier
            displace_modifier = bpy.context.object.modifiers.new(name="Displace", type='DISPLACE')
            displace_modifier.direction = 'Z'

            # Create texture from the image
            texture = bpy.data.textures.new(name="DisplaceTexture", type='IMAGE')
            texture.image = image

            # Assign texture to Displace modifier
            displace_modifier.vertex_group = vertex_group.name
            displace_modifier.texture = texture
            displace_modifier.strength = 1

        except Exception as e:
            self.report({'ERROR'}, f"Failed to load image or create cube: {e}")

        return {'FINISHED'}

# Panel to display the properties in the UI
class OBJECT_PT_png_cube_generator_panel(Panel):
    bl_label = "Tactile Model Generator"
    bl_idname = "OBJECT_PT_tactile_cube_generator_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Tactile Model'

    def draw(self, context):
        layout = self.layout
        props = context.scene.png_cube_generator_props

        layout.prop(props, "subdivision")
        layout.operator("object.set_image_path")
        layout.operator("object.create_cube")


# Registration
def register():
    bpy.utils.register_class(SetImagePathOperator)
    bpy.utils.register_class(CreateCubeOperator)
    bpy.utils.register_class(OBJECT_PT_png_cube_generator_panel)
    bpy.utils.register_class(CubeGeneratorProperties)
    bpy.types.Scene.png_cube_generator_props = bpy.props.PointerProperty(type=CubeGeneratorProperties)


def unregister():
    bpy.utils.unregister_class(SetImagePathOperator)
    bpy.utils.unregister_class(CreateCubeOperator)
    bpy.utils.unregister_class(OBJECT_PT_png_cube_generator_panel)
    bpy.utils.unregister_class(CubeGeneratorProperties)
    del bpy.types.Scene.png_cube_generator_props


if __name__ == "__main__":
    register()
